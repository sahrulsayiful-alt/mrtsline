# DocFlow Pro — Intelligent Document Capture

Prototype otomatisasi penginputan data dokumen:

**Kamera/Upload → OCR → Ekstraksi → Validasi → Duplicate Check → Database → Dashboard**

## Fitur
- Upload PDF/JPG/PNG/WEBP
- Kamera smartphone (HTTPS diperlukan)
- OCR English + Indonesian
- PDF multi-page (maksimum 5 halaman pada prototype)
- Ekstraksi field dasar dari label dokumen
- Human-in-the-loop validation
- Duplicate check berdasarkan Document Number pada mode demo
- Confidence OCR
- Search records
- Supabase PostgreSQL atau localStorage
- Responsive desktop/mobile
- Siap GitHub Pages

## Jalankan lokal
Gunakan VS Code Live Server atau:

```bash
python -m http.server 5500
```

Buka `http://localhost:5500`.

## Supabase
1. Buat project Supabase.
2. SQL Editor → jalankan `schema.sql`.
3. Ambil Project URL + anon/public key.
4. Isi `config.js`.

```js
export const SUPABASE_URL = "https://xxxx.supabase.co";
export const SUPABASE_ANON_KEY = "PUBLIC_ANON_KEY";
export const USE_SUPABASE = true;
```

Jangan pernah memasukkan `service_role` key ke GitHub/frontend.

## GitHub
```bash
git init
git add .
git commit -m "Build DocFlow Pro OCR automation"
git branch -M main
git remote add origin https://github.com/USERNAME/docflow-ocr.git
git push -u origin main
```

Aktifkan:
GitHub → Settings → Pages → Deploy from branch → main → /root.

## Alur pekerjaan nyata
1. Operator membuka aplikasi.
2. Scan dokumen menggunakan kamera HP atau upload PDF.
3. OCR membaca dokumen.
4. Sistem mengekstrak field.
5. Operator memeriksa field dan memperbaiki jika OCR salah.
6. Sistem melakukan duplicate check.
7. Operator menyimpan.
8. Data masuk PostgreSQL.
9. Dashboard menampilkan record.

## Untuk production perusahaan
Prototype ini sengaja tidak menyimpan secret backend di frontend. Untuk implementasi production tambahkan:
- Supabase Auth / SSO
- Role: Admin, Operator, Supervisor
- Row Level Security per user/departemen
- Storage file asli
- Audit trail
- Approval
- Duplicate detection yang lebih kuat
- Validasi format nomor dokumen
- Confidence threshold + manual review queue
- API/backend untuk secret dan business rules
- Backup dan retention policy
- Monitoring OCR errors

## Batasan prototype
OCR dapat salah membaca karakter seperti O/0, I/1, S/5, atau angka pada dokumen buram. Karena itu tahap validasi operator tetap dipertahankan sebelum database.
