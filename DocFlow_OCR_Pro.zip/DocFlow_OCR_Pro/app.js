import {SUPABASE_URL,SUPABASE_ANON_KEY,USE_SUPABASE} from "./config.js";

const $=id=>document.getElementById(id);
const fields=["documentNumber","documentDate","reference","customer","origin","destination","quantity","weight"];
let file=null,raw="",confidence=null,stream=null;

function setFile(f){
  if(!f)return;
  if(!(f.type.startsWith("image/")||f.type==="application/pdf"))return alert("File harus berupa gambar atau PDF.");
  file=f;$("selected").classList.remove("hidden");$("selectedName").textContent=f.name;
  $("selectedSize").textContent=`${(f.size/1024/1024).toFixed(2)} MB • ${f.type}`;
  $("process").disabled=false;
}
$("file").onchange=e=>setFile(e.target.files[0]);
$("drop").ondragover=e=>{e.preventDefault();$("drop").classList.add("drag")};
$("drop").ondragleave=()=>$("drop").classList.remove("drag");
$("drop").ondrop=e=>{e.preventDefault();$("drop").classList.remove("drag");setFile(e.dataTransfer.files[0])};
$("removeFile").onclick=()=>reset();

$("uploadTab").onclick=()=>{$("uploadTab").classList.add("active");$("cameraTab").classList.remove("active");$("uploadPane").classList.remove("hidden");$("cameraPane").classList.add("hidden")};
$("cameraTab").onclick=()=>{$("cameraTab").classList.add("active");$("uploadTab").classList.remove("active");$("cameraPane").classList.remove("hidden");$("uploadPane").classList.add("hidden")};

$("startCamera").onclick=async()=>{
 try{
  stream=await navigator.mediaDevices.getUserMedia({video:{facingMode:{ideal:"environment"},width:{ideal:1920}},audio:false});
  $("video").srcObject=stream;$("takePhoto").disabled=false;
 }catch(e){alert("Kamera tidak dapat diakses. Pastikan HTTPS dan izin kamera aktif.")}
};
$("stopCamera").onclick=stopCamera;
function stopCamera(){if(stream){stream.getTracks().forEach(t=>t.stop());stream=null}$("video").srcObject=null;$("takePhoto").disabled=true}
$("takePhoto").onclick=()=>{
 const v=$("video"),c=$("canvas");c.width=v.videoWidth;c.height=v.videoHeight;c.getContext("2d").drawImage(v,0,0);
 c.toBlob(blob=>setFile(new File([blob],"camera-capture.jpg",{type:"image/jpeg"})),"image/jpeg",.92);
};

async function pdfToImages(f){
 const pdfjs=await import("https://cdnjs.cloudflare.com/ajax/libs/pdf.js/4.10.38/pdf.min.mjs");
 pdfjs.GlobalWorkerOptions.workerSrc="https://cdnjs.cloudflare.com/ajax/libs/pdf.js/4.10.38/pdf.worker.min.mjs";
 const pdf=await pdfjs.getDocument({data:await f.arrayBuffer()}).promise, out=[];
 for(let i=1;i<=Math.min(pdf.numPages,5);i++){
  const p=await pdf.getPage(i),v=p.getViewport({scale:2}),c=document.createElement("canvas");
  c.width=v.width;c.height=v.height;await p.render({canvasContext:c.getContext("2d"),viewport:v}).promise;out.push(c)
 } return out;
}
function progress(p,t){$("progressBox").classList.remove("hidden");$("progressBar").style.width=p+"%";$("progressPct").textContent=Math.round(p)+"%";$("progressLabel").textContent=t}

async function ocr(f){
 const T=await import("https://cdn.jsdelivr.net/npm/tesseract.js@5/dist/tesseract.esm.min.js");
 const imgs=f.type==="application/pdf"?await pdfToImages(f):[f],w=await T.createWorker("eng+ind",1,{logger:m=>{if(m.status==="recognizing text")progress(20+m.progress*70,"OCR membaca dokumen...")}});
 let text="",scores=[];
 for(let i=0;i<imgs.length;i++){progress(15+i/imgs.length*75,`Processing page ${i+1}/${imgs.length}`);const r=await w.recognize(imgs[i]);text+=(text?"\n\n":"")+r.data.text;scores.push(r.data.confidence||0)}
 await w.terminate();return{text,confidence:scores.reduce((a,b)=>a+b,0)/scores.length}
}
function after(text,labels){
 for(const l of text.split(/\n/)){const x=l.trim(),low=x.toLowerCase();const hit=labels.find(a=>low.includes(a));if(hit){const p=x.split(/[:=]\s*/);if(p[1])return p.slice(1).join(":").trim()}}
 return "";
}
function extract(t){
 const date=(t.match(/\b(20\d{2})[-\/](\d{1,2})[-\/](\d{1,2})\b/)||[]);
 const num=s=>{const m=(s||"").match(/[\d.]+/);return m?m[0]:""};
 return{
  documentNumber:after(t,["document no","doc no","document number","nomor dokumen"]),
  documentDate:date[1]?`${date[1]}-${String(date[2]).padStart(2,"0")}-${String(date[3]).padStart(2,"0")}`:"",
  reference:after(t,["awb","reference","ref no","shipment"]),
  customer:after(t,["customer","shipper","company","consignee"]),
  origin:after(t,["origin","from","asal"]),
  destination:after(t,["destination","to","tujuan"]),
  quantity:num(after(t,["quantity","qty","jumlah"])),
  weight:num(after(t,["weight","gross weight","berat"]))
 }
}
$("process").onclick=async()=>{
 try{$("process").disabled=true;progress(5,"Preparing...");
  const r=await ocr(file);raw=r.text;confidence=r.confidence;$("raw").value=raw;
  const d=extract(raw);fields.forEach(k=>$(k).value=d[k]||"");
  $("statConfidence").textContent=Math.round(confidence)+"%";$("ocrState").textContent="PROCESSED";$("ocrState").className="pill green";
  progress(100,"OCR completed");validate();
 }catch(e){$("validation").textContent="OCR error: "+e.message;$("validation").className="message warn"}finally{$("process").disabled=false}
};
fields.forEach(k=>$(k).oninput=validate);
function data(){return Object.fromEntries(fields.map(k=>[k,$(k).value.trim()]))}
function validate(){
 if(!raw){$("save").disabled=true;return}
 const d=data(),miss=["documentNumber","reference","customer"].filter(k=>!d[k]);
 $("validation").textContent=miss.length?`Periksa field: ${miss.join(", ")}. Lengkapi jika diketahui.`:"Data lengkap dan siap disimpan.";
 $("validation").className="message "+(miss.length?"warn":"ok");$("save").disabled=false
}
$("copy").onclick=async()=>{await navigator.clipboard.writeText($("raw").value);$("copy").textContent="Copied";setTimeout(()=>$("copy").textContent="Copy",1000)};

async function save(){
 const d=data(),record={...d,raw_text:raw,ocr_confidence:confidence,source_file:file?.name||"",created_at:new Date().toISOString()};
 if(USE_SUPABASE){
  const r=await fetch(`${SUPABASE_URL}/rest/v1/document_records`,{method:"POST",headers:{apikey:SUPABASE_ANON_KEY,Authorization:`Bearer ${SUPABASE_ANON_KEY}`,"Content-Type":"application/json",Prefer:"return=minimal"},body:JSON.stringify(record)});
  if(!r.ok)throw Error(await r.text())
 }else{
  const a=JSON.parse(localStorage.getItem("docflow_pro_records")||"[]");
  const duplicate=a.some(x=>(x.documentNumber||"").toLowerCase()===(record.documentNumber||"").toLowerCase()&&(record.documentNumber||""));
  if(duplicate&&!confirm("Document Number sudah pernah disimpan. Tetap simpan?"))return;
  a.unshift(record);localStorage.setItem("docflow_pro_records",JSON.stringify(a.slice(0,300)))
 }
 await load();alert(USE_SUPABASE?"Record berhasil disimpan ke database.":"Record tersimpan di Local Demo.");
}
$("save").onclick=()=>save().catch(e=>alert("Gagal menyimpan: "+e.message));

async function getRows(){
 if(USE_SUPABASE){const r=await fetch(`${SUPABASE_URL}/rest/v1/document_records?select=*&order=created_at.desc&limit=100`,{headers:{apikey:SUPABASE_ANON_KEY,Authorization:`Bearer ${SUPABASE_ANON_KEY}`});return r.ok?await r.json():[]}
 return JSON.parse(localStorage.getItem("docflow_pro_records")||"[]")
}
function esc(v){return String(v??"").replace(/[&<>"']/g,m=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[m]))}
async function load(){
 const rows=await getRows(),q=($("search").value||"").toLowerCase();
 const filtered=rows.filter(r=>JSON.stringify(r).toLowerCase().includes(q));
 $("statTotal").textContent=rows.length;
 const today=new Date().toISOString().slice(0,10);$("statToday").textContent=rows.filter(r=>(r.created_at||"").slice(0,10)===today).length;
 $("tbody").innerHTML=filtered.length?filtered.map(r=>`<tr><td>${new Date(r.created_at).toLocaleString("id-ID")}</td><td>${esc(r.documentNumber)}</td><td>${esc(r.reference)}</td><td>${esc(r.customer)}</td><td>${esc(r.origin)}</td><td>${esc(r.destination)}</td><td>${r.ocr_confidence?Math.round(r.ocr_confidence)+"%":"—"}</td><td><span class="pill green">SAVED</span></td></tr>`).join(""):`<tr><td colspan="8" style="text-align:center;color:#9aa5b5">Belum ada record.</td></tr>`
}
$("search").oninput=load;$("refresh").onclick=load;
function reset(){stopCamera();file=null;raw="";confidence=null;$("file").value="";$("selected").classList.add("hidden");$("process").disabled=true;$("save").disabled=true;$("raw").value="";fields.forEach(k=>$(k).value="");$("ocrState").textContent="WAITING";$("ocrState").className="pill gray";$("progressBox").classList.add("hidden");$("validation").textContent="Belum ada data yang diproses.";$("validation").className="message"}
$("resetBtn").onclick=reset;
$("dbMode").textContent=USE_SUPABASE?"Supabase PostgreSQL":"Local Browser Demo";$("modePill").textContent=USE_SUPABASE?"SUPABASE CONNECTED":"DEMO MODE";
load();
