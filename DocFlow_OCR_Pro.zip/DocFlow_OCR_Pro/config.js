// PUBLIC configuration only.
// Never put Supabase service_role/private secrets here.
export const SUPABASE_URL = "";
export const SUPABASE_ANON_KEY = "";
export const USE_SUPABASE = Boolean(SUPABASE_URL && SUPABASE_ANON_KEY);
